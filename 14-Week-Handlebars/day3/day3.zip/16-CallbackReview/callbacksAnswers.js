// 2. Answer: 12 + 9 = 21

// 3. Answer: 4 + 18 = 22

// 4. Answer: 4 + 9 = 13

// 5. Answer: 8 + 3 = 11

// 6. Answer: undefined

// 7. Answer: 12 + 5 = 17
