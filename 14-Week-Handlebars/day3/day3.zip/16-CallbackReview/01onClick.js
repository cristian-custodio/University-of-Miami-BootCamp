// 1. Explain the on click code below.

// 2. When the page loads does the anonymous function get executed?

// 3. When does the anonymous function get executed?


$("#boomButton").on("click", function() {
  alert("boom");
});
